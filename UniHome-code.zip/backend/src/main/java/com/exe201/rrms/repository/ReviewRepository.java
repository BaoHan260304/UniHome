package com.exe201.rrms.repository;

import com.exe201.rrms.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByPropertyIdAndStatusOrderByCreatedAtDesc(Long propertyId, String status);
    long countByUserId(Long userId);
}