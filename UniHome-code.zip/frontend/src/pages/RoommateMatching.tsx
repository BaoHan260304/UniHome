export { default } from './MatchingPage';
